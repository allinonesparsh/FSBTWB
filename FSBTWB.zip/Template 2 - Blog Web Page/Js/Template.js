// Working
let Done = "Done, it is working.";
let Not_done = "Not Woring";

// Pls, Read This...
// You Need To Change The Title Of Website To Go In Index.html File And Change
// You Need To Add Favicon take a Image On Your Main Folder Rename The Image To Favicon.ico

// Enter Your Data
let Title = "Enter Your Blog Title"; // Tip - Use Max To Max 2 - 3 Word Title.
let Logo = "Enter Your Logo Url"; // Tip - Use Transparent Image In Logo. 
let main_image = "Enter Col Image Url"; // Enter Url Of Which Image Do You Want To Show In Main Section. 
let Short_des = "Enter Your Short Description."; // Instruction - The Lenght Of Short Description Is 25 to 28 Words.  
let About_us_1 = " Enter About Test For First Para"; // Instruction - The Lenght Of Question Is 50 to 55 Words.
let About_us = "Enter About Text" + "<br><br>" + "Enter About Text" + "<br><br>" + "Enter About Text" + "<br><br>" +  "Enter About Text" + "<br><br>" + "By " + Title; // Enter About Text In 4 para.
let About_img = "Enter Url Of About Image."; // Tip - Use Dark Theam Image In About Section.
let Your_tel_number = "Enter Your Tel Number"; // This Number Use In Contract Us Section Only.
let Terms_ = "Enter Terms Text" + "<br><br>" + "Enter Terms Text" + "<br><br>" + "Enter Terms Text" + "<br><br>" + "By " + Title; // Enter Term Text In 3 para.
let Privacy_policy = "Enter Privacy Policy" + "<br><br>" + "Enter Privacy Policy Text" + "<br><br>" + "Enter Privacy Policy Text" + "<br><br>" + "By " + Title; // Enter Privacy Policy Text In 3 para.

// Enter Information For FAQ Section
// Enter 5 Question With Answer For FAQ Section 
// Instruction - The Lenght Of Question Is 7 to 10 Words & The Lenght Of Ans Is 15 To 22 Words.
let ques1 = "Enter First Question For FAQ.";
let ans1 = "Enter Answer Of First Question.";
let ques2 = "Enter First Question For FAQ.";
let ans2 = "Enter Answer Of First Question.";
let ques3 = "Enter First Question For FAQ.";
let ans3 = "Enter Answer Of First Question.";
let ques4 = "Enter First Question For FAQ.";
let ans4 = "Enter Answer Of First Question.";
let ques5 = "Enter First Question For FAQ.";
let ans5 = "Enter Answer Of First Question.";

// Template
let template = `<section id="all_elements" style="display: grid;">
<div class="items" id="item1" name="navbar">
    <header id='header'>
        <img src='${Logo}' width="40" height="40" alt="Logo">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home' style="color: gray;">Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
            </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US"
                    class='nav-link Contract_US'>Contract us</a></li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${About_img}');">
    <br><br><br>
    <h1 id="Main_hading">Home - ${Title}</h1>
    <p>${Short_des}</p>
    <button onclick="Showblog();" id="New_blog_button">Blog Page</button>
</div>
<div class="items" id="item3">
    <div>
        <input class="input" type="text" placeholder="Search Now">
        <input class="button" type="submit">
    </div>
</div>
<div class="items" id="item4">
    <h1 class="heading">Popular Blog</h1>
    <div id="popular_blog">
        <div class="card" id="card1">
            <div class="img">

            </div>
            <h3 class="Card_title hover">Happy Mother Day</h3>
            <p class="post_data hover">26/4/24</p>
            <p class="des hover">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
            </p>
            <p class="tag">
                Lorem,<br> ipsum.
            </p>
        </div>
        <div class="card" id="card2">
            <div class="img">

            </div>
            <h3 class="Card_title hover">Happy Mother Day</h3>
            <p class="post_data hover">26/4/24</p>
            <p class="des hover">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
            </p>
            <p class="tag">
                Lorem,<br> ipsum.
            </p>
        </div>
        <div class="card" id="card3">
            <div class="img">

            </div>
            <h3 class="Card_title hover">Happy Mother Day</h3>
            <p class="post_data hover">26/4/24</p>
            <p class="des hover">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
            </p>
            <p class="tag">
                Lorem,<br> ipsum.
            </p>
        </div>
        <div class="card" id="card4">
            <div class="img">

            </div>
            <h3 class="Card_title hover">Happy Mother Day</h3>
            <p class="post_data hover">26/4/24</p>
            <p class="des hover">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
            </p>
            <p class="tag">
                Lorem,<br> ipsum.
            </p>
        </div>
    </div>
</div>
<div class="items" id="item5">
    <h2 class="heading">About US</h2>
    <div id="about_section">
        <div class="aboutcomponets" id="aboutimg" style="background-image: url("${About_img}")">

        </div>

        <div class="aboutcomponets" id="abouttext">
            <p>${About_us_1}</p>
        </div>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url("${Logo}")></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>
<section id="about" style="display: none;">
<div class="items" id="item1_about" name="navbar">
    <header id='header'>
        <img src='${Logo}' width="40" height="40" alt="Image">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'
                    style="color: gray;">About</a> </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US"
                    class='nav-link Contract_US'>Contract us</a> </li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${main_image}');">
    <br><br><br>
    <h1 id="Main_hading">About US - ${Title}</h1>
    <p>${Short_des}</p>
    <button href="" id="New_blog_button">Blog Page</button>
</div>
<div id="about_contant">
    <div class="items" id="item5">
        <h2 class="heading">About US</h2>
        <div id="about_section_page">
            <div class="aboutcomponets" id="aboutimg" style="background-image: url('${About_img}')">
            </div>
            <div class="aboutcomponets" id="abouttext">
                <p class="about_para">
                    ${About_us_1}
                </p>
            </div>
        </div>
        <p class="pcontent-width" id="all_text_about">${About_us}</p>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>
<section id="blog" style="display: none;">
<div class="items" id="item1_blog" name="navbar">
    <header id='header'>
        <img src='${Logo}' width="40" height="40" alt="Image">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
            </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'
                    style="color: gray;">Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US"
                    class='nav-link Contract_US'>Contract us</a> </li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${main_image}');">
    <br><br><br>
    <h1 id="Main_hading">Blog - ${Title}</h1>
    <p>${Short_des}</p>
    <button href="" id="New_blog_button">Blog Page</button>
</div>
<div class="blog_contant">
    <div class="items" id="item4">
        <div id="popular_blog">
            <div class="card" id="card1">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card2">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card3">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card4">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card5">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card6">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card7">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card8">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card9">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card10">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card11">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card12">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card13">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card14">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card15">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card16">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card17">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card18">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card19">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card20">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card21">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card22">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card23">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
            <div class="card" id="card24">
                <div class="img">

                </div>
                <h3 class="Card_title hover">Happy Mother Day</h3>
                <p class="post_data hover">26/4/24</p>
                <p class="des hover">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dignissimos.
                </p>
                <p class="tag">
                    Lorem,<br> ipsum.
                </p>
            </div>
        </div>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>
<section id="contract_us" style="display: none;">
<div class="items" id="item1_contract" name="navbar">
    <header id='header'>
        <img src='${Logo}' width="40" height="40" alt="Image">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
            </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'
                    style="color: gray;">Contract us</a> </li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${main_image}');">
    <br><br><br>
    <h1 id="Main_hading">Contract US - ${Title}</h1>
    <p>${Short_des}</p>
    <button href="" id="New_blog_button">Blog Page</button>
</div>
<div class="contrct">
    <div class="contract-us-contant">
        <p>Helpline No - ${Your_tel_number}</p>
        <h2>Leave Our Expricence Of This Blog Page...</h2>
        <input type="text" id="first_name" placeholder="Please Enter First Name">
        <input type="text" id="last_name" placeholder="Please Enter Last Name">
        <br>
        <input type="email" id="email_id" placeholder="Please Enter Email">
        <br>
        <textarea required id="message" style="height: 30vh;"
            placeholder="Please Enter Your Expricence"></textarea>
        <br>
        <button type="submit" id="button_submit">Submit</button>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>
<section id="FAQ" class="FAQ_page" style="display: none;">
<div class="items" id="item1_FAQ" name="navbar">
    <header id='header'>
        <img src='${Logo}' widht="40" height="40" alt="Image">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
            </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US"
                    class='nav-link Contract_US'>Contract us</a> </li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${main_image}');">
    <br><br><br>
    <h1 id="Main_hading">FAQ - ${Title}</h1>
    <p>${Short_des}</p>
    <button href="" id="New_blog_button">Blog Page</button>
</div>
<div class="FAQ-section">
    <div class="innerFaq">
        <details class="ques-ans">
            <summary class="ques">${ques1}</summary>
            <p class="ans"> Ans. ${ans1}</p>
        </details>
        <details class="ques-ans">
            <summary class="ques">${ques2}</summary>
            <p class="ans"> Ans. ${ans2}</p>
        </details>
        <details class="ques-ans">
            <summary class="ques">${ques3}</summary>
            <p class="ans"> Ans. ${ans3}</p>
        </details>
        <details class="ques-ans">
            <summary class="ques">${ques4}</summary>
            <p class="ans"> Ans. ${ans4}</p>
        </details>
        <details class="ques-ans">
            <summary class="ques">${ques5}</summary>
            <p class="ans"> Ans. ${ans5}</p>
        </details>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>
<section id="terms" class="terms" style="display: none;">
<div class="items" id="item1_terms" name="navbar">
    <header id='header'>
        <img src='${Logo}' width="40" height="40" alt="Image">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
            </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US"
                    class='nav-link Contract_US'>Contract us</a> </li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${main_image}');">
    <br><br><br>
    <h1 id="Main_hading">Terms - ${Title}</h1>
    <p>${Short_des}</p>
    <button href="" id="New_blog_button">Blog Page</button>
</div>
<div class="terms-con">
    <div class="inner-terms-con">
        <p class="terms-all">${Terms_}</p>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>
<section class="privacy_p" id="post_p" style="display: none;">
<div class="items" id="item1_privacy" name="navbar">
    <header id='header'>
        <img src='${Logo}' width="40" height="40" alt="Image">
        <ul id='ul'>
            <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
            <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
            </li>
            <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
            <li class='li'> <a onclick="Showcontract();" id="Contract_US"
                    class='nav-link Contract_US'>Contract us</a> </li>
        </ul>
    </header>
</div>
<div class="items" id="item2" style="background-image: url('${main_image}');">
    <br><br><br>
    <h1 id="Main_hading">Privacy Policy - ${Title}</h1>
    <p>${Short_des}</p>
    <button href="" id="New_blog_button">Blog Page</button>
</div>
<div class="Privacy_policy">
    <div class="inner_privacy_policy">
        <p>${Privacy_policy}</p>
    </div>
</div>
<div class="items" id="item6">
    <div id="footer">
        <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
        <div class="footer_item" id="footer_menu">
            <div id="menu_outer_footer">
                <ul class="footer_inner_menu">
                    <h3>All Pages</h3>
                    <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                    <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                    <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                </ul>
                <ul class="footer_inner_menu">
                    <h3>Policy</h3>
                    <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                    <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                    <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <div class="footer_item" id="copyright">
            <p>Copyright &copy; By ${Title}</p>
        </div>
    </div>
</div>
</section>`;

// Put Template On HTMl File 
let all_components = document.getElementById("all_components").innerHTML = template;