// All Page
let home = document.getElementById("all_elements");
let about = document.getElementById("about");
let blog = document.getElementById("blog");
let contract_US = document.getElementById("contract_us");
let FAQ = document.getElementById("FAQ");
let Terms = document.getElementById("terms");
let Privacypolicy = document.getElementById("post_p");
let postpage = document.getElementById("post_page");

// Function For Go On The Top
function Gototop() {
    window.scrollTo(0, 0);
}

// Changing Page 
function Showhome() {
    home.style.display = "grid";
    about.style.display = "none";
    blog.style.display = "none";
    contract_US.style.display = "none";
    FAQ.style.display = "none";
    Terms.style.display = "none";
    Privacypolicy.style.display = "none";

    // For Go To Top
    Gototop();
};

function Showabout() {
    home.style.display = "none";
    about.style.display = "block";
    blog.style.display = "none";
    contract_US.style.display = "none";
    FAQ.style.display = "none";
    Terms.style.display = "none";
    Privacypolicy.style.display = "none";

    // For Go To Top
    Gototop();
};

function Showblog() {
    home.style.display = "none";
    about.style.display = "none";
    blog.style.display = "block";
    contract_US.style.display = "none";
    FAQ.style.display = "none";
    Terms.style.display = "none";
    Privacypolicy.style.display = "none";

    // For Go To Top
    Gototop();
};

function Showcontract() {
    home.style.display = "none";
    about.style.display = "none";
    blog.style.display = "none";
    contract_US.style.display = "block";
    FAQ.style.display = "none";
    Terms.style.display = "none";
    Privacypolicy.style.display = "none";

    // For Go To Top
    Gototop();
};

function ShowFAQ() {
    home.style.display = "none";
    about.style.display = "none";
    blog.style.display = "none";
    contract_US.style.display = "none";
    FAQ.style.display = "block";
    Terms.style.display = "none";
    Privacypolicy.style.display = "none";

    // For Go To Top
    Gototop();
};

function Showterms() {
    home.style.display = "none";
    about.style.display = "none";
    blog.style.display = "none";
    contract_US.style.display = "none";
    FAQ.style.display = "none";
    Terms.style.display = "block";
    Privacypolicy.style.display = "none";

    // For Go To Top
    Gototop();
};

function Showprivacypolicy() {
    home.style.display = "none";
    about.style.display = "none";
    blog.style.display = "none";
    contract_US.style.display = "none";
    FAQ.style.display = "none";
    Terms.style.display = "none";
    Privacypolicy.style.display = "block";

    // For Go To Top
    Gototop();
};

// Card System
fetch("post.ano").then(response => response.json()).then(Data => {

    // Some Important Variable
    let title;

    // For Divide all post into normol or popular.
    let num = 0;

    // Get All object key
    Data.Posts.forEach(post => {
        // Functiom For Add Event On Card
        function addpostlink(id, content) {
            document.getElementById(`${id}`).addEventListener("click", () => {
                // Save All Of Title 
                let titles = Data.Posts.map(post => post.Title);

                console.log(titles);
                console.log("done");
                function getimageurl(Title) {
                    // Find Index
                    let index = titles.indexOf(Title);
                    let imageurl = Data.Posts[index].Postlink;

                    return imageurl;
                };

                function getcontent(Title) {
                    // Find Index
                    let index = titles.indexOf(Title);
                    let content = Data.Posts[index].Description;

                    return content;
                };

                home.style.display = "none";
                about.style.display = "none";
                blog.style.display = "none";
                contract_US.style.display = "none";
                FAQ.style.display = "none";
                Terms.style.display = "none";
                Privacypolicy.style.display = "none";
                postpage.style.display = "flex";
                document.getElementById("postpageimage").setAttribute("src", getimageurl(id));
                document.getElementById("postpagetext").innerText = getcontent(id);
            });
        };
        
        let box = document.getElementById("popular_blog");
        let allblogbox = document.getElementById("popular_blog_");
        title = post.Title;
        console.log(title);

        let newcard = document.createElement("div");
        newcard.classList.add("card");
        newcard.id = post.Title;

        let cardimage = document.createElement("div");
        cardimage.classList.add("img");

        let cardheading = document.createElement("h3");
        cardheading.classList.add("Card_title");
        cardheading.classList.add("hover");
        cardheading.innerText = post.Title;

        let carddescription = document.createElement("p");
        carddescription.classList.add("des");
        carddescription.classList.add("hover");
        carddescription.innerText = post.Short_Description;

        let carddate = document.createElement("p");
        carddate.classList.add("post_data");
        carddate.classList.add("hover");
        carddate.innerText = post.Date;

        let cardtag = document.createElement("p");
        cardtag.classList.add("tag");
        cardtag.innerText = post.tag1;

        let cardtag2 = document.createElement("p");
        cardtag.classList.add("tag");
        cardtag.innerText = post.tag2;

        newcard.appendChild(cardimage);
        newcard.appendChild(cardheading);
        newcard.appendChild(carddate);
        newcard.appendChild(carddescription);
        newcard.appendChild(cardtag);
        newcard.appendChild(cardtag2);

        if (num < 4) {
            box.appendChild(newcard);
            num++;
        } else {
            allblogbox.appendChild(newcard);
        };

        // Prepare Content For Post
        let content = {
            imageurl: post.Postlink,
            description: post.Description
        };

        // Call Function For Go To Post Page
        addpostlink(title, content);
    });
});