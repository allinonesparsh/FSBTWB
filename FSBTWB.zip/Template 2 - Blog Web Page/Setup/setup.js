// Working
let Done = "Done, It Is Working.";

// Veriable
// let Jsondata;
let post_data;
let new_post;
let jsonfile;

// Create a new Date object
let currentDate = new Date();

// Get the current day, month, and year
let day = currentDate.getDate();
let month = currentDate.getMonth() + 1; // January is 0
let year = currentDate.getFullYear();


// Write The Template 
function startwork() {
    // Collect All In For Information. 
    let Title = document.getElementById("Title").value;
    let Logo = document.getElementById("Logo_Url").value;
    let main_image = document.getElementById("Enter_Image_Url").value;
    let Short_des = document.getElementById("Short_Descraption").value;
    let About_us_ = document.getElementById("Short_Para").value;
    let About_us_1 = document.getElementById("Para_For_About_Section1").value;
    let About_us_2 = document.getElementById("Para_For_About_Section2").value;
    let About_us_3 = document.getElementById("Para_For_About_Section3").value;
    let About_us_4 = document.getElementById("Para_For_About_Section4").value;
    let About_us = About_us_1 + "<br><br>" + About_us_2 + "<br><br>" + About_us_3 + "<br><br>" + About_us_4 + "<br><br>" + "By " + Title;
    let About_img = document.getElementById("About_image").value;
    let Your_tel_number = document.getElementById("Tel_Number").value;
    let Terms_para1 = document.getElementById("Terms_para1").value;
    let Terms_para2 = document.getElementById("Terms_para2").value;
    let Terms_para3 = document.getElementById("Terms_para3").value;
    let Terms_para4 = document.getElementById("Terms_para4").value;
    let Terms_ = Terms_para1 + "<br><br>" + Terms_para2 + "<br><br>" + Terms_para3 + "<br><br>" + Terms_para4 + "By " + Title;
    let Privacy_policy_para1 = document.getElementById("Privacy_policy_para1").value;
    let Privacy_policy_para2 = document.getElementById("Privacy_policy_para2").value;
    let Privacy_policy_para3 = document.getElementById("Privacy_policy_para3").value;
    let Privacy_policy_para4 = document.getElementById("Privacy_policy_para4").value;
    let Privacy_policy = Privacy_policy_para1 + "<br><br>" + Privacy_policy_para2 + "<br><br>" + Privacy_policy_para3 + "<br><br>" + Privacy_policy_para4 + "By " + Title;
    let ques1 = document.getElementById("FAQ_Question1").value;
    let ans1 = document.getElementById("FAQ_Answer1").value;
    let ques2 = document.getElementById("FAQ_Question2").value;
    let ans2 = document.getElementById("FAQ_Answer2").value;
    let ques3 = document.getElementById("FAQ_Question3").value;
    let ans3 = document.getElementById("FAQ_Answer3").value;
    let ques4 = document.getElementById("FAQ_Question4").value;
    let ans4 = document.getElementById("FAQ_Answer4").value;
    let ques5 = document.getElementById("FAQ_Question5").value;
    let publicKey = document.getElementById("public_key").value;
    let ServiceKey = document.getElementById("Service_Key").value;
    let TemplateKey = document.getElementById("Template_Key").value;

    // Write The Code
    let template = `<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${Title}</title>
        <link rel="stylesheet" href="style.css">
            <!-- Email.js -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
    <script type="text/javascript">
        (function() {
            // https://dashboard.emailjs.com/admin/account
            emailjs.init({
              publicKey: "${publicKey}",
            });
        })();
    </script>
    </head>
    
    <body>
        <section id="all_elements" style="display: grid;">
            <div class="items" id="item1" name="navbar">
                <header id='header'>
                    <img src='${Logo}' width="40" height="40" alt="Logo">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'
                                style="color: gray;">Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
                        </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'>Contract
                                us</a></li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${About_img}');">
                <br><br><br>
                <h1 id="Main_hading">Home - ${Title}</h1>
                <p>${Short_des}</p>
                <button onclick="Showblog();" id="New_blog_button">Blog Page</button>
            </div>
            <div class="items" id="item3">
                <div>
                    <input class="input" type="text" placeholder="Search Now">
                    <input class="button" type="submit">
                </div>
            </div>
            <div class="items" id="item4">
                <h1 class="heading">Popular Blog</h1>
                <div id="popular_blog">
                
                </div>
            </div>
            <div class="items" id="item5">
                <h2 class="heading">About US</h2>
                <div id="about_section">
                    <div class="aboutcomponets" id="aboutimg" style="background-image: url('${About_img}')">
    
                    </div>
    
                    <div class="aboutcomponets" id="abouttext">
                        <p>${About_us_}</p>
                    </div>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
        <section id="about" style="display: none;">
            <div class="items" id="item1_about" name="navbar">
                <header id='header'>
                    <img src='${Logo}' width="40" height="40" alt="Image">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'
                                style="color: gray;">About</a> </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'>Contract
                                us</a> </li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${main_image}');">
                <br><br><br>
                <h1 id="Main_hading">About US - ${Title}</h1>
                <p>${Short_des}</p>
                <button href="" id="New_blog_button">Blog Page</button>
            </div>
            <div id="about_contant">
                <div class="items" id="item5">
                    <h2 class="heading">About US</h2>
                    <div id="about_section_page">
                        <div class="aboutcomponets" id="aboutimg" style="background-image: url('${About_img}')">
                        </div>
                        <div class="aboutcomponets" id="abouttext">
                            <p class="about_para">
                                ${About_us_}
                            </p>
                        </div>
                    </div>
                    <p class="pcontent-width" id="all_text_about">${About_us}</p>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
        <section id="blog" style="display: none;">
            <div class="items" id="item1_blog" name="navbar">
                <header id='header'>
                    <img src='${Logo}' width="40" height="40" alt="Image">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
                        </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'
                                style="color: gray;">Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'>Contract
                                us</a> </li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${main_image}');">
                <br><br><br>
                <h1 id="Main_hading">Blog - ${Title}</h1>
                <p>${Short_des}</p>
                <button href="" id="New_blog_button">Blog Page</button>
            </div>
            <div class="blog_contant">
                <div class="items" id="item4">
                    <div id="popular_blog">
                    
                    </div>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
        <section id="contract_us" style="display: none;">
            <div class="items" id="item1_contract" name="navbar">
                <header id='header'>
                    <img src='${Logo}' width="40" height="40" alt="Image">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
                        </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'
                                style="color: gray;">Contract us</a> </li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${main_image}');">
                <br><br><br>
                <h1 id="Main_hading">Contract US - ${Title}</h1>
                <p>${Short_des}</p>
                <button href="" id="New_blog_button">Blog Page</button>
            </div>
            <div class="contrct">
                <div class="contract-us-contant">
                    <p>Helpline No - ${Your_tel_number}</p>
                    <h2>Leave Our Expricence Of This Blog Page...</h2>
                    <input type="text" id="first_name" placeholder="Please Enter First Name">
                    <input type="text" id="last_name" placeholder="Please Enter Last Name">
                    <br>
                    <input type="email" id="email_id" placeholder="Please Enter Email">
                    <br>
                    <textarea required id="message" style="height: 30vh;"
                        placeholder="Please Enter Your Expricence"></textarea>
                    <br>
                    <button type="submit" id="button_submit">Submit</button>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
        <section id="FAQ" class="FAQ_page" style="display: none;">
            <div class="items" id="item1_FAQ" name="navbar">
                <header id='header'>
                    <img src='${Logo}' widht="40" height="40" alt="Image">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
                        </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'>Contract
                                us</a> </li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${main_image}');">
                <br><br><br>
                <h1 id="Main_hading">FAQ - ${Title}</h1>
                <p>${Short_des}</p>
                <button href="" id="New_blog_button">Blog Page</button>
            </div>
            <div class="FAQ-section">
                <div class="innerFaq">
                    <details class="ques-ans">
                        <summary class="ques">${ques1}</summary>
                        <p class="ans"> Ans. ${ans1}</p>
                    </details>
                    <details class="ques-ans">
                        <summary class="ques">${ques2}</summary>
                        <p class="ans"> Ans. ${ans2}</p>
                    </details>
                    <details class="ques-ans">
                        <summary class="ques">${ques3}</summary>
                        <p class="ans"> Ans. ${ans3}</p>
                    </details>
                    <details class="ques-ans">
                        <summary class="ques">${ques4}</summary>
                        <p class="ans"> Ans. ${ans4}</p>
                    </details>
                    <details class="ques-ans">
                        <summary class="ques">${ques5}</summary>
                        <p class="ans"> Ans. ${ans5}</p>
                    </details>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
        <section id="terms" class="terms" style="display: none;">
            <div class="items" id="item1_terms" name="navbar">
                <header id='header'>
                    <img src='${Logo}' width="40" height="40" alt="Image">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
                        </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'>Contract
                                us</a> </li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${main_image}');">
                <br><br><br>
                <h1 id="Main_hading">Terms - ${Title}</h1>
                <p>${Short_des}</p>
                <button href="" id="New_blog_button">Blog Page</button>
            </div>
            <div class="terms-con">
                <div class="inner-terms-con">
                    <p class="terms-all">${Terms_}</p>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="privacy_p" id="post_p" style="display: none;">
            <div class="items" id="item1_privacy" name="navbar">
                <header id='header'>
                    <img src='${Logo}' width="40" height="40" alt="Image">
                    <ul id='ul'>
                        <li class='li'> <a onclick="Showhome();" id="Home" class='nav-link Home'>Home</a> </li>
                        <li class='li'> <a onclick="Showabout();" id="About_US" class='nav-link About_US'>About</a>
                        </li>
                        <li class='li'> <a onclick="Showblog();" id="Blog" class='nav-link Blog'>Blog</a> </li>
                        <li class='li'> <a onclick="Showcontract();" id="Contract_US" class='nav-link Contract_US'>Contract
                                us</a> </li>
                    </ul>
                </header>
            </div>
            <div class="items" id="item2" style="background-image: url('${main_image}');">
                <br><br><br>
                <h1 id="Main_hading">Privacy Policy - ${Title}</h1>
                <p>${Short_des}</p>
                <button href="" id="New_blog_button">Blog Page</button>
            </div>
            <div class="Privacy_policy">
                <div class="inner_privacy_policy">
                    <p>${Privacy_policy}</p>
                </div>
            </div>
            <div class="items" id="item6">
                <div id="footer">
                    <div class="footer_item" id="footer_logo" style="background-image: url('${Logo}')"></div>
                    <div class="footer_item" id="footer_menu">
                        <div id="menu_outer_footer">
                            <ul class="footer_inner_menu">
                                <h3>All Pages</h3>
                                <li><a onclick="Showabout();" class="About_US_F">About US</a></li>
                                <li><a onclick="Showblog();" class="Blog_F">Blog</a></li>
                                <li><a onclick="Showcontract();" class="Contract_US_F">Contract Us</a></li>
                            </ul>
                            <ul class="footer_inner_menu">
                                <h3>Policy</h3>
                                <li><a onclick="ShowFAQ();" class="FAQ">FAQ</a></li>
                                <li><a onclick="Showterms();" class="Terms">Terms</a></li>
                                <li><a onclick="Showprivacypolicy();" class="Privacypolicy">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer_item" id="copyright">
                        <p>Copyright &copy; By ${Title}</p>
                    </div>
                </div>
            </div>
        </section>
    
        <!-- JS -->
        <script src="main.js"></script>

        <script>
        function SendMail() {
    var params = {
        from_name : document.getElementById("first_name").value,
        email_id : document.getElementById("email_id").value,
        message : document.getElementById("message").value
    };
    emailjs.send("${ServiceKey}", "${TemplateKey}", params).then(alert("Your Message Was Sending..."));
};
    </script>
    </body>
    
    </html>`;
    console.log(template);

    function Createmainfile() {
        let htmlfile = template;

        // Push Add In JSON File
        // Create a Blob with the file content
        let blob = new Blob([htmlfile], { type: 'text/plain' });

        // Create A Download Link
        let downloadLink = document.createElement("a");
        downloadLink.href = window.URL.createObjectURL(blob);
        downloadLink.download = "index.html";
        downloadLink.click();
        console.log("Your HTML File Is Downloded.");
    }
    Createmainfile();
};

// Function For App Post 
function addpost() {
    let user_number = document.getElementById("Post_Number").value;
    let post_title = document.getElementById("Post_title").value;
    let Short_description = document.getElementById("Shortdescription").value;
    let post_description = document.getElementById("description").value;
    let postLink = document.getElementById("postLink").value;
    let tag1 = document.getElementById("tags1").value;
    let tag2 = document.getElementById("tags2").value;


    // Add Json File
    fetch('../../post.json')
        .then(response => {
            // Check if the response is successful
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            // Parse the JSON response
            return response.json();
        })
        .then(data => {
            // Covert JSON Data Into Javascript Object
            // Add Post Data In JSON

            // Add New Data To JSON File.
            new_post = {
                "Title": `{post_title}`,
                "Description": `{ post_description `,
                "Short_Description": `{ Short_description }`,
                "Postlink": `{ postLink }`,
                "Date": `${day} / ${month} / ${year}`,
                "tag1": `${tag1}`,
                "tag2": `${tag2}`
            };

            function Createjsonfile() {
                jsonfile = data.Posts.push(new_post);
                let a = JSON.stringify(data);

                // Push Add In JSON File
                // Create a Blob with the file content
                let blob = new Blob([a], { type: 'text/plain' });

                // Create A Download Link
                let downloadLink = document.createElement("a");
                downloadLink.href = window.URL.createObjectURL(blob);
                downloadLink.download = 'post.ano';
                downloadLink.click();
                console.log("Your JSON File Is Downloded");
            }
            Createjsonfile();
        })
        .catch(error => {
            // Handle errors
            console.error('There was a problem with the fetch operation:', error);
        });
}

